﻿{
	"version": 1498716338,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"images/background.png",
		"images/playeranimation-sheet0.png",
		"images/playeranimation-sheet1.png",
		"images/player-sheet0.png",
		"images/fire-sheet0.png",
		"images/sky.png",
		"images/enemyanimation-sheet0.png",
		"images/enemyanimation-sheet1.png",
		"images/explode-sheet0.png",
		"images/skillz.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}